from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.secret_key = "replace-this-key-before-deployment"
DB_NAME = "app.db"

def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, bio TEXT DEFAULT '')""")
        conn.execute("""CREATE TABLE IF NOT EXISTS meetings (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            title TEXT NOT NULL, meeting_date TEXT NOT NULL, notes TEXT DEFAULT '',
            summary TEXT DEFAULT '', created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id))""")

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def landing():
    return redirect(url_for("dashboard")) if session.get("user_id") else render_template("landing.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 6:
            flash("Enter all details. Password must have at least 6 characters.", "danger")
        else:
            try:
                with db() as conn:
                    conn.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",
                                 (name, email, generate_password_hash(password)))
                flash("Account created. Please log in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("This email is already registered.", "danger")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        with db() as conn:
            user = conn.execute("SELECT * FROM users WHERE email=?",
                (request.form.get("email", "").strip().lower(),)).fetchone()
        if user and check_password_hash(user["password"], request.form.get("password", "")):
            session.clear()
            session["user_id"], session["name"] = user["id"], user["name"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("landing"))

@app.route("/dashboard")
@login_required
def dashboard():
    with db() as conn:
        count = conn.execute("SELECT COUNT(*) FROM meetings WHERE user_id=?", (session["user_id"],)).fetchone()[0]
        recent = conn.execute("SELECT * FROM meetings WHERE user_id=? ORDER BY id DESC LIMIT 5",
                              (session["user_id"],)).fetchall()
    return render_template("dashboard.html", count=count, recent=recent)

@app.route("/workspace", methods=["GET", "POST"])
@login_required
def workspace():
    if request.method == "POST":
        title, date = request.form.get("title", "").strip(), request.form.get("meeting_date", "")
        if title and date:
            with db() as conn:
                conn.execute("""INSERT INTO meetings(user_id,title,meeting_date,notes,summary,created_at)
                    VALUES(?,?,?,?,?,?)""", (session["user_id"], title, date,
                    request.form.get("notes", "").strip(), request.form.get("summary", "").strip(),
                    datetime.now().isoformat(timespec="minutes")))
            flash("Meeting saved.", "success")
            return redirect(url_for("history"))
        flash("Meeting title and date are required.", "danger")
    return render_template("workspace.html", today=datetime.now().strftime("%Y-%m-%d"))

@app.route("/history")
@login_required
def history():
    with db() as conn:
        meetings = conn.execute("SELECT * FROM meetings WHERE user_id=? ORDER BY meeting_date DESC, id DESC",
                                (session["user_id"],)).fetchall()
    return render_template("history.html", meetings=meetings)

@app.route("/meeting/<int:meeting_id>")
@login_required
def meeting_detail(meeting_id):
    with db() as conn:
        meeting = conn.execute("SELECT * FROM meetings WHERE id=? AND user_id=?",
                               (meeting_id, session["user_id"])).fetchone()
    if not meeting:
        flash("Meeting not found.", "danger")
        return redirect(url_for("history"))
    return render_template("meeting_detail.html", meeting=meeting)

@app.route("/meeting/<int:meeting_id>/delete", methods=["POST"])
@login_required
def delete_meeting(meeting_id):
    with db() as conn:
        conn.execute("DELETE FROM meetings WHERE id=? AND user_id=?", (meeting_id, session["user_id"]))
    flash("Meeting deleted.", "success")
    return redirect(url_for("history"))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    with db() as conn:
        user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
        if request.method == "POST":
            name, bio = request.form.get("name", "").strip(), request.form.get("bio", "").strip()
            if name:
                conn.execute("UPDATE users SET name=?, bio=? WHERE id=?", (name, bio, session["user_id"]))
                session["name"] = name
                flash("Profile updated.", "success")
                return redirect(url_for("profile"))
            flash("Name cannot be empty.", "danger")
    return render_template("profile.html", user=user)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
