MEETSPACE - MEMBER 1 FLASK WORKING MODEL

Run:
1. Extract this ZIP and open the folder in VS Code.
2. In the VS Code terminal run: python -m venv venv
3. Activate it: venv\Scripts\activate  (Windows)
4. Install: pip install -r requirements.txt
5. Start: python app.py
6. Open: http://127.0.0.1:5000

The SQLite database (app.db) is created automatically.
Includes landing page, register/login, dashboard, workspace, meeting history,
meeting detail/delete, and profile editing. Meeting summaries are entered manually.
For deployment, replace app.secret_key and disable debug mode.
